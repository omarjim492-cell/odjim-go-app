/* ODJIM GO — Firebase Messaging Service Worker / v1.0.0-rc.1 */
importScripts('https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js');
firebase.initializeApp({apiKey:"AIzaSyCUB0t9wvZp2pXhjYmv2G7AeToWNekJRTg",authDomain:"odjim-solution.firebaseapp.com",projectId:"odjim-solution",storageBucket:"odjim-solution.firebasestorage.app",messagingSenderId:"165673018775",appId:"1:165673018775:web:c8b4cc6345b854763950d2"});
const messaging=firebase.messaging();
messaging.onBackgroundMessage((payload)=>{const n=payload.notification||{},d=payload.data||{};self.registration.showNotification(n.title||d.title||'ODJIM GO',{body:n.body||d.body||'Tens uma nova notificação.',icon:n.icon||d.icon||'./icons/icon-192.png',badge:d.badge||'./icons/icon-192.png',data:{url:d.url||d.click_action||'./'}});});
self.addEventListener('notificationclick',(event)=>{event.notification.close();const url=(event.notification.data&&event.notification.data.url)||'./';event.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{for(const client of list){if('focus' in client){if('navigate' in client)client.navigate(url);return client.focus();}}if(clients.openWindow)return clients.openWindow(url);}));});
