# ODJIM GO v1.0.0-rc.1

RC técnico preparado com Service Worker FCM integrado.

**Produção:** requer deploy e teste real no Firebase; este pacote não afirma que o deploy foi executado.
