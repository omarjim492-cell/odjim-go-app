ODJIM GO — R16.26 QA

Foram executados testes estáticos sobre o pacote refatorado:
- estrutura de entrada;
- referências CSS/JS;
- ausência de CSS/JS inline;
- integridade básica da IIFE;
- presença de Firebase/ODJIM;
- referência de avaliação;
- resolução de referências locais;
- balanceamento básico de tags HTML;
- verificação de configuração VAPID/API.

IMPORTANTE:
Este QA é estático. Não representa teste ponta a ponta contra Firebase publicado,
Authentication, Firestore, Storage ou FCM.
